# innovesense  > 2024-03-20 11:45am
https://universe.roboflow.com/mini-project-nw0bd/innovesense

Provided by a Roboflow user
License: CC BY 4.0

